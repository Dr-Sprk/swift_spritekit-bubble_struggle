//
//  GameSceneLevel1.swift
//  Bubble Struggle
//
//  Created by Arjun Sharma on 5/10/19.
//  Copyright © 2019 Arjun Sharma. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameSceneLevel1: SKScene, SKPhysicsContactDelegate {
    //Initialise the bitmask values for collisions
    let BubbleCategory: UInt32 = 0x1 << 0
    let PlayerCategory: UInt32 = 0x1 << 1
    let PopperCategory: UInt32 = 0x1 << 2
    
    //Set up variables for the bubble and the player
    var player: SKSpriteNode?
    var bubble: SKSpriteNode?
    
    //Set up variables for the left and right buttons
    var leftButton: SKSpriteNode?
    var rightButton: SKSpriteNode?
    
    //Set up bools for whether the character sprite should be moving left and right or not
    var moveLeft: Bool = false
    var moveRight: Bool = false
    
    //Set up bool for whether the popper is instantiated
    var popperMovement: Bool = false
    
    //Set up popper sprite
    var popper = SKSpriteNode(imageNamed: "popper.png") as SKSpriteNode
    
    //Set up ground variable and timerBar as SKSpriteNodes
    var ground: SKSpriteNode?
    var timerBar: SKSpriteNode?
    
    //Set up bool for whether the player is dead or not
    var isDead: Bool = false
    
    //Set up variables for the label nodes
    var scoreLabel: SKLabelNode?
    var levelLabel: SKLabelNode?
    var userLabel: SKLabelNode?
    
    //Set up variables for the number of lives the player has, their score, username, the timer count, variable used for pausing timer, bools for if the level is complete and whether they are reset, and finally the definition of countdown as a Timer
    var lives = 5
    var score = 0
    var username: String = ""
    var timer:Double = 120
    var beforePausedTime: Double = 0
    var levelComplete: Bool = false
    var isReset = false
    var countdown: Timer?
    
    override func didMove(to view: SKView) {
        //Function used to ensure the continuity between number of lives and number of lives shown on screen
        if lives != 5 {
            for x in 0...(4-lives) {
                childNode(withName: "life\(5-x)")?.removeFromParent()
            }
        }
        
        //Defines player as sprite and instantiates physics body
        player = childNode(withName: "player") as? SKSpriteNode
        player!.physicsBody!.categoryBitMask = PlayerCategory
        player!.physicsBody!.contactTestBitMask = BubbleCategory
        player!.physicsBody!.collisionBitMask = BubbleCategory
        
        //Defines bubble as sprite and instantiates physics body, as well as the starting impulse
        bubble = childNode(withName: "Bubble") as? SKSpriteNode
        bubble!.texture = SKTexture(imageNamed: "yellowBall")
        bubble!.physicsBody!.categoryBitMask = BubbleCategory
        bubble!.physicsBody!.contactTestBitMask = PopperCategory | PlayerCategory
        bubble!.physicsBody!.collisionBitMask = PlayerCategory
        bubble!.physicsBody!.applyImpulse(CGVector(dx: 80, dy: 40))
        
        //Defines popper as sprite and instantiates physics body
        popper.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: (popper.texture?.size().width)!, height: (popper.texture?.size().height)!))
        popper.physicsBody!.friction = 1
        popper.physicsBody!.restitution = 0
        popper.physicsBody!.linearDamping = 1
        popper.physicsBody!.angularDamping = 1
        popper.physicsBody!.allowsRotation = false
        popper.physicsBody!.affectedByGravity = false
        popper.physicsBody!.categoryBitMask = PopperCategory
        popper.physicsBody!.contactTestBitMask = BubbleCategory
        popper.physicsBody!.collisionBitMask = 0
        
        //Defines the score label as SKLabelNode, font definition, as well as setting the text to be the player's score
        scoreLabel = childNode(withName: "score") as? SKLabelNode
        scoreLabel?.fontName = "cartoon"
        scoreLabel?.text = String(score)
        
        //Defines the username label as SKLabelNode, font definition, as well as setting the text to be the player's username
        userLabel = childNode(withName: "username") as? SKLabelNode
        userLabel?.fontName = "cartoon"
        userLabel?.text = username
        
        //Defines the level label as SKLabelNode, and font definition
        levelLabel = childNode(withName: "level") as? SKLabelNode
        levelLabel?.fontName = "cartoon"
        
        //Defines left and right sprites
        leftButton = childNode(withName: "leftButton") as? SKSpriteNode
        rightButton = childNode(withName: "rightButton") as? SKSpriteNode
        
        //Sets physics world operator as current scene and defines the edges of the frame as a physics body as a part of the scene
        physicsWorld.contactDelegate = self
        physicsBody = SKPhysicsBody(edgeLoopFrom: frame)
        
        //Defines the timerBar
        timerBar = childNode(withName: "timerBar") as? SKSpriteNode
        
        //Defines countdown and sets it to subtract 0.1 from timer every 0.1 seconds
        countdown = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { x in
            self.timer -= 0.1
        }
    }
    
    func didBegin(_ contact: SKPhysicsContact) {
        //Checks if the collision is between player and bubble
        if ((contact.bodyA.categoryBitMask == PlayerCategory) && (contact.bodyB.categoryBitMask == BubbleCategory) || (contact.bodyA.categoryBitMask == BubbleCategory) && (contact.bodyB.categoryBitMask == PlayerCategory)) {
            //If it is, freeze the physics world, set the player as dead, through variable and texture, and run either resetGame or gameOver depending on the player's number of lives
            self.physicsWorld.speed = 0
            isDead = true
            player?.texture = SKTexture(imageNamed: "deathImage")
            let fadeOut = SKAction.fadeOut(withDuration: 0.5)
            player?.run(fadeOut)
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                self.isPaused = true
                if self.lives > 1 {
                    self.resetGame()
                } else {
                    self.gameOver()
                }
            }
            //Checks if collision is between bubble and popper
        } else if ((contact.bodyA.categoryBitMask == PopperCategory) && (contact.bodyB.categoryBitMask == BubbleCategory)) || ((contact.bodyA.categoryBitMask == BubbleCategory) && (contact.bodyB.categoryBitMask == PopperCategory)) {
            //If it is, check if it bodyA is the bubble
            if contact.bodyA.categoryBitMask == BubbleCategory {
                //If it is define hitBubble as bodyA's node
                let hitBubble = contact.bodyA.node as? SKSpriteNode
                //And add a score which is the size of the bubble multiplied by the percent of time left for the level
                score += Int(Double(hitBubble!.size.width) * (timer/120))
                //Check if the bubble is more than 20 wide
                if Int((hitBubble?.size.width)!) > 20 {
                    //If it is, create a bubble with identical textures, and physics, but half the size under the variable name bubble1
                    let bubble1 = SKSpriteNode(texture: hitBubble!.texture, size: CGSize(width: (hitBubble?.size.width)!/2, height: (hitBubble?.size.height)!/2))
                    bubble1.physicsBody = SKPhysicsBody(circleOfRadius: (bubble1.size.width)/2)
                    bubble1.position = CGPoint(x: ((hitBubble?.position.x)! + (hitBubble?.size.width)!/2), y: (hitBubble?.position.y)!)
                    bubble1.physicsBody!.friction = 0
                    bubble1.physicsBody!.restitution = 1
                    bubble1.physicsBody!.linearDamping = 0
                    bubble1.physicsBody!.angularDamping = 0
                    bubble1.physicsBody!.allowsRotation = false
                    bubble1.physicsBody!.affectedByGravity = true
                    bubble1.physicsBody!.categoryBitMask = BubbleCategory
                    bubble1.physicsBody!.contactTestBitMask = PopperCategory | PlayerCategory
                    bubble1.physicsBody!.collisionBitMask = PlayerCategory
                    
                    //And create anotherbubble with identical textures, and physics, but half the size under the variable name bubble2
                    let bubble2 = SKSpriteNode(texture: hitBubble!.texture, size: CGSize(width: (hitBubble?.size.width)!/2, height: (hitBubble?.size.height)!/2))
                    bubble2.physicsBody = SKPhysicsBody(circleOfRadius: (bubble2.size.width)/2)
                    bubble2.position = CGPoint(x: ((hitBubble?.position.x)! - (hitBubble?.size.width)!/2), y: (hitBubble?.position.y)!)
                    bubble2.physicsBody!.friction = 0
                    bubble2.physicsBody!.restitution = 1
                    bubble2.physicsBody!.linearDamping = 0
                    bubble2.physicsBody!.angularDamping = 0
                    bubble2.physicsBody!.allowsRotation = false
                    bubble2.physicsBody!.affectedByGravity = true
                    bubble2.physicsBody!.categoryBitMask = BubbleCategory
                    bubble2.physicsBody!.contactTestBitMask = PopperCategory | PlayerCategory
                    bubble2.physicsBody!.collisionBitMask = PlayerCategory
                    
                    //So, essentially, those 2 bubbles of half the hitBubble's original size were made to mirror the popping mechanism in the real game
                    //Add the two half size bubbles
                    self.addChild(bubble1)
                    self.addChild(bubble2)
                    //And remove the bubble that was hit
                    hitBubble?.removeFromParent()
                    //And apply a starting impulse upon the two balls
                    bubble1.physicsBody?.applyImpulse(CGVector(dx: bubble1.size.width/4, dy: bubble1.size.height/4))
                    bubble2.physicsBody?.applyImpulse(CGVector(dx: -bubble2.size.width/4, dy: bubble2.size.height/4))
                    //Also, remove the popper, and set it's movement variable to false, as it has collided with something
                    popper.removeFromParent()
                    popperMovement = false
                } else {
                    //However, now, if the bubble is not greater than 20, just remove it without splitting, otherwise it would become too small!
                    hitBubble?.removeFromParent()
                    //And again, remove the popper, and set it's movement variable to false, as it has collided with something
                    popper.removeFromParent()
                    popperMovement = false
                }
                //Now check if bodyB is the bubble, and perform exactly the same functions as above. As they are the same, I am not going to comment this bit, because there is no point
            } else if contact.bodyB.categoryBitMask == BubbleCategory {
                let hitBubble = contact.bodyB.node as? SKSpriteNode
                score += Int(Double(hitBubble!.size.width) * (timer/120))
                if Int((hitBubble?.size.width)!) > 20 {
                    let bubble1 = SKSpriteNode(texture: hitBubble!.texture, size: CGSize(width: (hitBubble?.size.width)!/2, height: (hitBubble?.size.height)!/2))
                    bubble1.physicsBody = SKPhysicsBody(circleOfRadius: (bubble1.size.width)/2)
                    bubble1.position = CGPoint(x: ((hitBubble?.position.x)! + (hitBubble?.size.width)!/2), y: (hitBubble?.position.y)!)
                    bubble1.physicsBody!.friction = 0
                    bubble1.physicsBody!.restitution = 1
                    bubble1.physicsBody!.linearDamping = 0
                    bubble1.physicsBody!.angularDamping = 0
                    bubble1.physicsBody!.allowsRotation = false
                    bubble1.physicsBody!.affectedByGravity = true
                    bubble1.physicsBody!.categoryBitMask = BubbleCategory
                    bubble1.physicsBody!.contactTestBitMask = PopperCategory | PlayerCategory
                    bubble1.physicsBody!.collisionBitMask = PlayerCategory
                    
                    let bubble2 = SKSpriteNode(texture: hitBubble!.texture, size: CGSize(width: (hitBubble?.size.width)!/2, height: (hitBubble?.size.height)!/2))
                    bubble2.physicsBody = SKPhysicsBody(circleOfRadius: (bubble2.size.width)/2)
                    bubble2.position = CGPoint(x: ((hitBubble?.position.x)! - (hitBubble?.size.width)!/2), y: (hitBubble?.position.y)!)
                    bubble2.physicsBody!.friction = 0
                    bubble2.physicsBody!.restitution = 1
                    bubble2.physicsBody!.linearDamping = 0
                    bubble2.physicsBody!.angularDamping = 0
                    bubble2.physicsBody!.allowsRotation = false
                    bubble2.physicsBody!.affectedByGravity = true
                    bubble2.physicsBody!.categoryBitMask = BubbleCategory
                    bubble2.physicsBody!.contactTestBitMask = PopperCategory | PlayerCategory
                    bubble2.physicsBody!.collisionBitMask = PlayerCategory
                    
                    self.addChild(bubble1)
                    self.addChild(bubble2)
                    hitBubble?.removeFromParent()
                    bubble1.physicsBody?.applyImpulse(CGVector(dx: bubble1.size.width/4, dy: bubble1.size.height/4))
                    bubble2.physicsBody?.applyImpulse(CGVector(dx: -bubble2.size.width/4, dy: bubble2.size.height/4))
                    popper.removeFromParent()
                    popperMovement = false
                } else {
                    hitBubble?.removeFromParent()
                    popper.removeFromParent()
                    popperMovement = false
                }
            }
        }
    }
    
    func touchDown(atPoint pos : CGPoint) {
        
    }
    
    func touchMoved(toPoint pos : CGPoint) {
        
    }
    
    func touchUp(atPoint pos : CGPoint) {
        
    }

    //Function is run everytime a touch event occurs
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        //These variables house the location information of the touch, as well as ensuring that only the first touch of the set is recognised
        let touch = touches.first!
        let touchLocation = touch.location(in: self)
        let touchedNode = atPoint(touchLocation)
        
        //Checks if leftButton node was touched and if so, set moveLeft to true
        if touchedNode.name == "leftButton" {
            moveLeft = true
        }
        
        //Checks if rightButton node was touched and if so, set moveRight to true
        if touchedNode.name == "rightButton" {
            moveRight = true
        }
        
        //Checks if pause node was touched and if so, run the pause function defined below
        if touchedNode.name == "pause" {
            paused()
        }
        
        //Checks if resumeButton or resumeLabel nodes were touched
        if touchedNode.name == "resumeButton" || touchedNode.name == "resumeLabel" {
            //And if so unpause the world
            self.isPaused = false
            //Set the speed back to 1
            self.physicsWorld.speed = 1
            //Set the timer to what it was before being paused
            timer = beforePausedTime
            //Go through and unpaused each node in the scene individually
            for node in self.children as [SKNode] {
                node.isPaused = false
            }
            
            //And remove all the pause screen related nodes
            childNode(withName: "pauseScreen")?.removeFromParent()
            childNode(withName: "pauseLabel")?.removeFromParent()
            childNode(withName: "resumeButton")?.removeFromParent()
            childNode(withName: "exitButton")?.removeFromParent()
            childNode(withName: "resumeLabel")?.removeFromParent()
            childNode(withName: "exitLabel")?.removeFromParent()
        }
        
        //Checks if exitButton or exitLabel nodes were touched, and transition back to `GameSceneStart`
        if touchedNode.name == "exitButton" || touchedNode.name == "exitLabel" {
            let newScene = GameSceneStart(fileNamed: "GameSceneStart")
            let transition = SKTransition.flipVertical(withDuration: 1.0)
            newScene?.scaleMode = .aspectFill
            scene?.view?.presentScene(newScene!, transition: transition)
        }
        
        //Checks if popperMovement is false, and if the shoot node was touched, and if so, creates the popper and places in the scene, setting popperMovement to true
        if popperMovement == false {
            if touchedNode.name == "shoot" {
                popper.size.height = 630
                popper.size.width = 8
                popper.zPosition = -1
                popper.position = CGPoint(x: player!.position.x, y: -475.5)
                self.addChild(popper)
                popperMovement = true
            }
        }
    }
    
    //Checks if the touch has moved, to facilitate easy use of controls on iPhone
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first!
        let touchLocation = touch.location(in: self)
        let touchedNode = atPoint(touchLocation)
        
        //If the new node's name is leftButton, set moveRight as false and moveLeft as true
        if touchedNode.name == "leftButton" {
            moveRight = false
            moveLeft = true
        }
        
        //If the new node's name is rightButton, set moveLeft as false and moveRight as true
        if touchedNode.name == "rightButton" {
            moveLeft = false
            moveRight = true
        }
    }
    
    //Checks if the touch event has ended
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        //If moveLeft was true, set moveLeft and moveRight as false, and set the texture as the normal straight texture
        if moveLeft == true {
            moveLeft = false
            moveRight = false
            player?.texture = SKTexture(imageNamed: "Player")
        }
        //If moveRight was true, set moveLeft and moveRight as false, and set the texture as the normal straight texture
        if moveRight == true {
            moveLeft = false
            moveRight = false
            player?.texture = SKTexture(imageNamed: "Player")
        }
    }
    
    //This is run every frame
    override func update(_ currentTime: TimeInterval) {
        //Variable that is reset as zero each frame, to recount the number of bubbles each frame
        var noOfBubbles: Int = 0
        //Ensure the width of the timerBar is its original width multiplied by the percentage of time left
        timerBar!.size.width = 1600 * CGFloat(timer/120)
        //Checks if moveLeft is true and if so subtracts 3 from the player's x value each frame, whilst also setting the texture as Left motion
        if moveLeft == true {
            player?.position.x -= 3
            player?.texture = SKTexture(imageNamed: "Left Motion")
        }
        //Checks if moveRight is true and if so add 3 to the player's x value each frame, whilst also setting the texture as Right motion
        if moveRight == true {
            player?.position.x += 3
            player?.texture = SKTexture(imageNamed: "Right Motion")
        }
        //Checks if popperMovement is true and if so adds 7.5 to the popper's y value each frame
        if popperMovement == true {
            popper.position.y += 7.5
        }
        //Checks if the popper's y position is greater than 76 and then removes it (as it has reached the top of the map), setting popperMovement to false
        if popper.position.y >= 76 {
            popper.removeFromParent()
            popperMovement = false
        }
        //Checks if isDead is true, and accordingly does or does not add 1 to the y position of the player every frame
        if isDead == true {
            player?.position.y += 1
        }
        //Keeps score label up to date
        scoreLabel?.text = String(score)
        //Search through all nodes and if the category bitmask is bubbleCategory, add one to noOfBubbles
        for node in self.children {
            if node.physicsBody?.categoryBitMask == BubbleCategory {
                noOfBubbles += 1
            }
        }
        //If noOfBubbles is 0, i.e. no bubbles were found and levelComplete is false, run levelCompleteFunc and set levelComplete to true
        if noOfBubbles == 0 {
            if !levelComplete {
                levelCompleteFunc()
                levelComplete = true
            }
        }
        
        //Checks if the timer is equal to or less than zero and if isReset is true
        if timer <= 0 && isReset == false {
            //If so, invalidate the countdown timer and loop through all nodes, and setting those with the category bitmask BubbleCategory as resting
            countdown?.invalidate()
            for node in self.children {
                if node.physicsBody?.categoryBitMask == BubbleCategory {
                    node.physicsBody?.isResting = true
                }
            }
            //Also, insert an SKLabelNode, saying time up
            let timeUpLabel = SKLabelNode(fontNamed: "cartoon")
            timeUpLabel.text = "Time up!"
            timeUpLabel.fontSize = 80
            timeUpLabel.fontColor = SKColor.systemYellow
            timeUpLabel.position = CGPoint(x: 0, y: 0)
            timeUpLabel.zPosition = 4
            timeUpLabel.alpha = 1
            self.addChild(timeUpLabel)
            //And after 3 seconds, remove the label and run resetGame, whilst also setting isReset to true
            Timer.scheduledTimer(withTimeInterval: 3, repeats: false) {_ in
                timeUpLabel.removeFromParent()
                self.resetGame()
            }
            isReset = true
        }
    }
    
    //Called when the game needs to be reset
    func resetGame() {
        //Set isDead to false to stop upward player movement
        isDead = false
        //Create a near 100% transparent layer above rest of scene to absorb touches, preventing unwanted player interaction during reset
        let alphaBackground = SKShapeNode(rectOf: CGSize(width: frame.width, height: frame.height))
        alphaBackground.zPosition = 3
        alphaBackground.position = CGPoint(x: 0, y: 0)
        alphaBackground.fillColor = SKColor.black
        alphaBackground.alpha = 0.01
        self.addChild(alphaBackground)
        //remove the popper and set its movement to false
        popper.removeFromParent()
        popperMovement = false
        //reset the player's position and texture
        player?.position = CGPoint(x: 0, y: -199.65)
        player?.texture = SKTexture(imageNamed: "Player")
        player?.alpha = 1
        //Resent the bubble's position
        bubble?.position = CGPoint(x: -4.943, y: 50)
        //Remove one life node and subtract one from the life count
        childNode(withName: "life" + String(lives))?.removeFromParent()
        lives -= 1
        //Begin to set things back to playing state, by removing the alpha layer
        alphaBackground.removeFromParent()
        //Unpause the scene and set the physics world speed to 1 to facilitate normal movement
        isPaused = false
        self.physicsWorld.speed = 1
        //Remove all pre-existing BallCategory nodes
        for node in self.children {
            if node.physicsBody?.categoryBitMask == BubbleCategory {
                node.removeFromParent()
            }
        }
        //Reset timer
        timer = 120
        //Readd the original bubble to the scene
        self.addChild(bubble!)
        //And to restart the game, apply an impulse to the ball and make the player resting, ready for input
        bubble!.physicsBody?.applyImpulse(CGVector(dx: 80, dy: 40))
        player?.physicsBody!.isResting = true
    }
    
    //Run when the player runs out of lives
    func gameOver() {
        //Freeze the game scene
        self.physicsWorld.speed = 0
        self.isPaused = false
        
        //Create a layer on top of the rest of the nodes to prevent any further user interaction with the scene
        let alphaBackground = SKShapeNode(rectOf: CGSize(width: frame.width, height: frame.height))
        alphaBackground.zPosition = 3
        alphaBackground.position = CGPoint(x: 0, y: 0)
        alphaBackground.fillColor = SKColor.black
        alphaBackground.alpha = 0
        
        //Create a game over label telling the user that it's game over
        let gameOverLabel = SKLabelNode(fontNamed: "cartoon")
        gameOverLabel.text = "Game Over"
        gameOverLabel.fontSize = 80
        gameOverLabel.fontColor = SKColor.systemYellow
        gameOverLabel.position = CGPoint(x: 0, y: 0)
        gameOverLabel.zPosition = 4
        gameOverLabel.alpha = 0
        
        //Create a small transition label which is a throwback to the original game, wherein a very similar label would appear
        let transitionLabel = SKLabelNode(fontNamed: "cartoon")
        transitionLabel.text = "And now for your score..."
        transitionLabel.fontSize = 50
        transitionLabel.position = CGPoint(x: 390, y: -200)
        transitionLabel.zPosition = 4
        transitionLabel.alpha = 0
        
        //Set up some fade in animations
        let fadeIn = SKAction.fadeIn(withDuration: 1)
        let mildFadeIn = SKAction.fadeAlpha(to: 0.7, duration: 1)
        
        //Add the alphaBackground and gameOverLabels to the scene
        self.addChild(alphaBackground)
        self.addChild(gameOverLabel)
        //And make them run their respective animations as they do so
        alphaBackground.run(mildFadeIn)
        gameOverLabel.run(fadeIn)
        //After 3 seconds, fade in the transition label
        Timer.scheduledTimer(withTimeInterval: 3, repeats: false) { x in
            self.addChild(transitionLabel)
            transitionLabel.run(fadeIn)
            x.invalidate()
            //And after another 2 seconds, switch to the GameSceneEndScore page, feeding through the user's name and score
            Timer.scheduledTimer(withTimeInterval: 2, repeats: false) { x in
                let newScene = GameSceneEndScore(fileNamed: "GameSceneEndScore")
                let transition = SKTransition.flipHorizontal(withDuration: 1)
                newScene?.username = self.username
                newScene?.score = self.score
                newScene?.scaleMode = .aspectFill
                self.scene?.view?.presentScene(newScene!, transition: transition)
                x.invalidate()
            }
        }
    }
    
    //Called when the game is paused
    func paused() {
        //Set variable beforePausedTime to the timer's present value, and freeze the scene
        beforePausedTime = timer
        self.isPaused = true
        self.physicsWorld.speed = 0
        for node in self.children as [SKNode] {
            node.isPaused = true
        }
        
        //Create a layer upon which the pause node items will be laid
        let pauseAlphaBackground = SKShapeNode(rectOf: CGSize(width: frame.width, height: frame.height))
        pauseAlphaBackground.zPosition = 3
        pauseAlphaBackground.name = "pauseScreen"
        pauseAlphaBackground.position = CGPoint(x: 0, y: 0)
        pauseAlphaBackground.fillColor = SKColor.black
        pauseAlphaBackground.alpha = 0.7
        
        //Create a pause screen heading
        let pausedHeader = SKLabelNode(fontNamed: "cartoon")
        pausedHeader.text = "Paused"
        pausedHeader.name = "pauseLabel"
        pausedHeader.zPosition = 4
        pausedHeader.fontColor = SKColor.systemYellow
        pausedHeader.fontSize = 55
        pausedHeader.position = CGPoint(x: 0, y: 60)
        
        //Create a resume button
        let resumeSquare = SKShapeNode(rectOf: CGSize(width: 400, height: 70))
        resumeSquare.zPosition = 4
        resumeSquare.name = "resumeButton"
        resumeSquare.fillColor = SKColor.systemRed
        resumeSquare.strokeColor = SKColor.systemYellow
        resumeSquare.lineWidth = 3
        resumeSquare.position = CGPoint(x: 0, y: 0)
        
        //Create a resume label for the button
        let resumeLabel = SKLabelNode(fontNamed: "cartoon")
        resumeLabel.zPosition = 5
        resumeLabel.text = "Back to game"
        resumeLabel.name = "resumeLabel"
        resumeLabel.fontColor = SKColor.systemYellow
        resumeLabel.position = CGPoint(x: 0, y: -10)
        
        //Create a exit button
        let exitSquare = SKShapeNode(rectOf: CGSize(width: 400, height: 70))
        exitSquare.zPosition = 4
        exitSquare.name = "exitButton"
        exitSquare.fillColor = SKColor.systemRed
        exitSquare.strokeColor = SKColor.systemYellow
        exitSquare.lineWidth = 3
        exitSquare.position = CGPoint(x: 0, y: -80)
        
        //Create a exit label for the button
        let exitLabel = SKLabelNode(fontNamed: "cartoon")
        exitLabel.zPosition = 5
        exitLabel.text = "Quit to main screen"
        exitLabel.name = "exitLabel"
        exitLabel.fontColor = SKColor.systemYellow
        exitLabel.position = CGPoint(x: 0, y: -90)
        
        //Add all the nodes that were just created
        self.addChild(pauseAlphaBackground)
        self.addChild(pausedHeader)
        self.addChild(resumeSquare)
        self.addChild(exitSquare)
        self.addChild(resumeLabel)
        self.addChild(exitLabel)
    }
    
    //Called when there are no bubble left
    func levelCompleteFunc() {
        //Freeze the scene
        self.physicsWorld.speed = 0
        self.isPaused = false
        
        //Create a congratulation label with random praising messages
        let congratsLabel = SKLabelNode(fontNamed: "cartoon")
        let textRandomiser = Int.random(in: 1...3)
        if textRandomiser == 1 {
            congratsLabel.text = "Congratulations!"
        } else if textRandomiser == 2 {
            congratsLabel.text = "Bravo!"
        } else {
            congratsLabel.text = "Awesome!"
        }
        congratsLabel.fontSize = 80
        congratsLabel.fontColor = SKColor.systemYellow
        congratsLabel.position = CGPoint(x: 0, y: 0)
        congratsLabel.zPosition = 4
        congratsLabel.alpha = 1
        
        //Add the remainder of the timer value and 250 to the player's score (the timer value as a bonus, and 250 for completing the level)
        score += Int(timer)
        score += 250
        
        //Creates a transparent layer to prevent user interaction during transition
        let endGameAlphaBackground = SKShapeNode(rectOf: CGSize(width: frame.width, height: frame.height))
        endGameAlphaBackground.zPosition = 3
        endGameAlphaBackground.position = CGPoint(x: 0, y: 0)
        endGameAlphaBackground.fillColor = SKColor.black
        endGameAlphaBackground.alpha = 0.01
        
        //Add created nodes to scene
        self.addChild(congratsLabel)
        self.addChild(endGameAlphaBackground)
        //After 3 seconds, present the next scene passing through the player's username, score, and life count
        Timer.scheduledTimer(withTimeInterval: 3, repeats: false) { x in
            let newScene = GameSceneLevel2(fileNamed: "GameSceneLevel2")
            let transition = SKTransition.flipHorizontal(withDuration: 1)
            newScene?.username = self.username
            newScene?.lives = self.lives
            newScene?.score = self.score
            newScene?.scaleMode = .aspectFill
            self.scene?.view?.presentScene(newScene!, transition: transition)
            x.invalidate()
        }
    }
}


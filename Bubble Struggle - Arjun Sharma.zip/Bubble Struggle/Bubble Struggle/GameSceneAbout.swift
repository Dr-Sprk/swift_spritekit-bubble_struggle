//
//  GameSceneAbout.swift
//  Bubble Struggle
//
//  Created by Arjun Sharma on 2/11/19.
//  Copyright © 2019 Arjun Sharma. All rights reserved.
//

import SpriteKit
import GameplayKit

//Initialise the scene class
class GameSceneAbout: SKScene {
    override func didMove(to view: SKView) {
        //Set the font of the specified SKLabelNodes
        (childNode(withName: "copyright") as? SKLabelNode)?.fontName = "cartoon"
        (childNode(withName: "overview") as? SKLabelNode)?.fontName = "cartoon"
        //Allow the overview SKLabelNode to be split over miltiple lines
        (childNode(withName: "overview") as? SKLabelNode)?.lineBreakMode = NSLineBreakMode.byWordWrapping
        (childNode(withName: "overview") as? SKLabelNode)?.numberOfLines = 0
        (childNode(withName: "overview") as? SKLabelNode)?.preferredMaxLayoutWidth = 325
    }

    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        //Get the first touch recognised and record its location within a variable
        let touch = touches.first!
        let touchLocation = touch.location(in: self)
        let touchedNode = atPoint(touchLocation)
        
        //Check if the touched node is the back symbol/button
        if touchedNode.name == "backSymbol" || touchedNode.name == "backButton" {
            //If so, switch back to `GameSceneStart` using the flipVertical transition
            let newScene = GameSceneStart(fileNamed: "GameSceneStart")
            let transition = SKTransition.flipVertical(withDuration: 1.0)
            newScene?.scaleMode = .aspectFill
            scene?.view?.presentScene(newScene!, transition: transition)
        }
    }
}

//
//  GameSceneEndScore.swift
//  Bubble Struggle
//
//  Created by Arjun Sharma on 2/11/19.
//  Copyright © 2019 Arjun Sharma. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameSceneEndScore: SKScene {
    var username: String?
    var score: Int?
    override func didMove(to view: SKView) {
        //Set the font of the specified nodes
        (childNode(withName: "score") as? SKLabelNode)?.fontName = "cartoon"
        (childNode(withName: "username") as? SKLabelNode)?.fontName = "cartoon"
        (childNode(withName: "title") as? SKLabelNode)?.fontName = "cartoon"
        (childNode(withName: "okLabel") as? SKLabelNode)?.fontName = "cartoon"
        
        //Set the text of the score and username nodes to be the value of the score and username variables respectively, fed from the level the player last played
        (childNode(withName: "score") as? SKLabelNode)?.text = String(score!)
        (childNode(withName: "username") as? SKLabelNode)?.text = username
        
        //If the score from the round of playing is higher than that stored under the HighestScore key...
        if (UserDefaults.standard.object(forKey: "HighestScore") as? Int ?? -1) < score! {
            //Define the HighestScore key as the player's score
            UserDefaults.standard.set(self.score, forKey:"HighestScore")
            //Define the HighestScoreUsername key as the player's username
            UserDefaults.standard.set(self.username, forKey:"HighestScoreUsername")
            //And then update and save these values to storage
            UserDefaults.standard.synchronize()
            //And just for fun, set the title as "New Highscore!"
            (childNode(withName: "title") as? SKLabelNode)?.text = "New Highscore!"
        }
    }

    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        //Get the first touch recognised and record its location within a variable
        let touch = touches.first!
        let touchLocation = touch.location(in: self)
        let touchedNode = atPoint(touchLocation)
        
        //Check if the touched node is the back symbol/button
        if touchedNode.name == "okLabel" || touchedNode.name == "okButton" {
            //If so, switch back to `GameSceneStart` using the flipVertical transition
            let newScene = GameSceneStart(fileNamed: "GameSceneStart")
            let transition = SKTransition.flipVertical(withDuration: 1.0)
            newScene?.scaleMode = .aspectFill
            scene?.view?.presentScene(newScene!, transition: transition)
        }
    }
}

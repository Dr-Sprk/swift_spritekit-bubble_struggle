//
//  GameSceneHighestScore.swift
//  Bubble Struggle
//
//  Created by Arjun Sharma on 2/11/19.
//  Copyright © 2019 Arjun Sharma. All rights reserved.
//

import SpriteKit
import GameplayKit

//Initialises scene class
class GameSceneHighestScore: SKScene {
    override func didMove(to view: SKView) {
        //Set the font of all the specified nodes
        (childNode(withName: "score") as? SKLabelNode)?.fontName = "cartoon"
        (childNode(withName: "username") as? SKLabelNode)?.fontName = "cartoon"
        (childNode(withName: "okLabel") as? SKLabelNode)?.fontName = "cartoon"
        
        //Check if the high score storage key is nil
        if (UserDefaults.standard.object(forKey: "HighestScore") as? Int) != nil {
            //If not, return the key HighestScore's value as the SKLabelNode score's text, and the key HighestScoreUsername's value as the SKLabelNode username's text
            (childNode(withName: "score") as? SKLabelNode)?.text = String((UserDefaults.standard.object(forKey: "HighestScore") as! Int))
            (childNode(withName: "username") as? SKLabelNode)?.text = UserDefaults.standard.object(forKey: "HighestScoreUsername") as? String
        } else {
            //If it is nill, then reposition the username node, and replace the text to say that there is no score stored yet; remove the score node as well, because it is not needed
            (childNode(withName: "username") as? SKLabelNode)?.text = "No scores recorded yet... try playing the game!"
            (childNode(withName: "username") as? SKLabelNode)?.fontSize = 12
            (childNode(withName: "username") as? SKLabelNode)?.position.x = -25
            (childNode(withName: "score") as? SKLabelNode)?.removeFromParent()
        }
    }

    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        //Get the first touch recognised and record its location within a variable
        let touch = touches.first!
        let touchLocation = touch.location(in: self)
        let touchedNode = atPoint(touchLocation)
        
        //Check if the touched node is the back symbol/button
        if touchedNode.name == "okLabel" || touchedNode.name == "okButton" {
            //If so, switch back to `GameSceneStart` using the flipVertical transition
            let newScene = GameSceneStart(fileNamed: "GameSceneStart")
            let transition = SKTransition.flipVertical(withDuration: 1.0)
            newScene?.scaleMode = .aspectFill
            scene?.view?.presentScene(newScene!, transition: transition)
        }
    }
}

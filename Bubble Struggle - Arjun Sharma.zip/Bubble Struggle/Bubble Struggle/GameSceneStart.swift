//
//  GameSceneStart.swift
//  Bubble Struggle
//
//  Created by Arjun Sharma on 30/10/19.
//  Copyright © 2019 Arjun Sharma. All rights reserved.
//


import SpriteKit
import GameplayKit

//Initialise the starting scene for the app
class GameSceneStart: SKScene {
    //A global variable is used so as to preserve the definitions from other functions and not assign the variable definition for every touch
    var textField: UITextField?
    
    //This is the "upon start" function for the scene
    override func didMove(to view: SKView) {
        //Just defining a custom font for each of my text nodes, nothing too fancy!
        (childNode(withName: "textPlay") as? SKLabelNode)?.fontName = "cartoon"
        (childNode(withName: "textHighscore") as? SKLabelNode)?.fontName = "cartoon"
        (childNode(withName: "textControls") as? SKLabelNode)?.fontName = "cartoon"
        (childNode(withName: "textAbout") as? SKLabelNode)?.fontName = "cartoon"
    }

    //This is the "upon touch" function and passes various pieces of data about the touch event
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        //These variables house the location information of the touch, as well as ensuring that only the first touch of the set is recognised
        let touch = touches.first!
        let touchLocation = touch.location(in: self)
        let touchedNode = atPoint(touchLocation)
        
        //Code hides keyboard on username screen upon touch anywhere else, thanks to: https://medium.com/@KaushElsewhere/how-to-dismiss-keyboard-in-a-view-controller-of-ios-3b1bfe973ad1
        view?.endEditing(true)
        
        //This checks if there is a node at the touched location with the name "playButton" or "textPlay"...
        if touchedNode.name == "playButton" || touchedNode.name == "textPlay" {
            //And creates a pop-up style overlay using an alpha SKShapeNode, set above the other node
            let alphaBackground = SKShapeNode(rectOf: CGSize(width: frame.width, height: frame.height))
            alphaBackground.zPosition = 3
            alphaBackground.position = CGPoint(x: 0, y: 0)
            alphaBackground.fillColor = SKColor.black
            alphaBackground.alpha = 0.8
            
            //This instantiates the title node upon the pop-up, using an SKLabelNode, setting the text, appearance and positioning of it
            let header = SKLabelNode(fontNamed: "cartoon")
            header.text = "Who are you?"
            header.fontSize = 20
            header.fontColor = SKColor.systemYellow
            header.position = CGPoint(x: 0, y: 40)
            header.zPosition = 4
            header.alpha = 1
            
            //This creates a SKShape node that is used as a button for the confirmation of the player's username, setting up the position and aesthetics of the button
            let okButton = SKShapeNode(rectOf: CGSize(width: 120, height: 30))
            okButton.zPosition = 4
            okButton.name = "okButton"
            okButton.fillColor = SKColor.systemRed
            okButton.strokeColor = SKColor.systemYellow
            okButton.lineWidth = 3
            okButton.position = CGPoint(x: 0, y: -50)
            
            //This is the text for the button, and where the positioning, text and appearance is set
            let okLabel = SKLabelNode(fontNamed: "cartoon")
            okLabel.zPosition = 5
            okLabel.name = "okLabel"
            okLabel.text = "Continue"
            okLabel.fontSize = 20
            okLabel.fontColor = SKColor.systemYellow
            okLabel.position = CGPoint(x: 0, y: -60)
            
            //This is where the text entry for the player's username is created and a variable is created to house the positioning and sizing information that will be applied to the text field
            let textFieldFrame = CGRect(origin: CGPoint(x: 250, y: 175), size: CGSize(width: 400, height: 50))
            //Here the actual text field global variable is written to and is intialised as a UITextField, setting the aesthetics of the text entry, as well as the type of keyboard that is to be relayed to the user to enter their username
            textField = UITextField(frame: textFieldFrame)
            textField!.backgroundColor = UIColor.systemYellow
            textField!.placeholder = "Enter username"
            textField!.font = UIFont(name: "cartoon", size: 40)
            textField!.keyboardType = UIKeyboardType.asciiCapable
            
            //Add all the nodes that were instantiated earlier to the view
            self.addChild(alphaBackground)
            self.addChild(header)
            self.addChild(okButton)
            self.addChild(okLabel)
            //As the text field is a UI item, it must be added as a subview to the view as it is not technically a node
            self.view?.addSubview(textField!)
        }
        
        //This checks if the node touched was the okButton/okLabel nodes that were initialised upon the play button touch...
        if touchedNode.name == "okLabel" || touchedNode.name == "okButton" {
            //And if so, get the new scene `GameSceneLevel1`, and store it within a variable..
            let newScene = GameSceneLevel1(fileNamed: "GameSceneLevel1")
            //Set a transition for switching scenes...
            let transition = SKTransition.flipVertical(withDuration: 1.0)
            //Pass the username from the UITextField to the other scene
            newScene?.username = String(textField?.text ?? "")
            //Make the other scene scale to fill the screen
            newScene?.scaleMode = .aspectFill
            //And finally switch to the new scene using the transition defined earlier
            scene?.view?.presentScene(newScene!, transition: transition)
            //And manually remove the text field from the view, as it isn't technically part of the scene, and is simply a subview
            textField?.removeFromSuperview()
        }
        
        //If the node touched is one of the highscore nodes...
        if touchedNode.name == "textHighscore" || touchedNode.name == "highscoreButton" {
            //Present the new scene in the same way as in the previous method, except present the `GameSceneHighestScore` this time
            let newScene = GameSceneHighestScore(fileNamed: "GameSceneHighestScore")
            let transition = SKTransition.flipVertical(withDuration: 1.0)
            newScene?.scaleMode = .aspectFill
            scene?.view?.presentScene(newScene!, transition: transition)
        }
        
        //If the node touched is one of the control nodes...
        if touchedNode.name == "textControls" || touchedNode.name == "controlsButton" {
            //Present the new scene in the same way as in the previous method, except present the `GameSceneControls` this time
            let newScene = GameSceneControls(fileNamed: "GameSceneControls")
            let transition = SKTransition.flipVertical(withDuration: 1.0)
            newScene?.scaleMode = .aspectFill
            scene?.view?.presentScene(newScene!, transition: transition)
        }
        
        //If the node touched is one of the about nodes...
        if touchedNode.name == "textAbout" || touchedNode.name == "aboutButton" {
            //Present the new scene in the same way as in the previous method, except present the `GameSceneAbout` this time
            let newScene = GameSceneAbout(fileNamed: "GameSceneAbout")
            let transition = SKTransition.flipVertical(withDuration: 1.0)
            newScene?.scaleMode = .aspectFill
            scene?.view?.presentScene(newScene!, transition: transition)
        }
    }
}

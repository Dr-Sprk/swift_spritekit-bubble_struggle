//
//  GameSceneControls.swift
//  Bubble Struggle
//
//  Created by Arjun Sharma on 2/11/19.
//  Copyright © 2019 Arjun Sharma. All rights reserved.
//

import SpriteKit
import GameplayKit

//Initialise the scene class
class GameSceneControls: SKScene {
    override func didMove(to view: SKView) {
        //Set the font and ability to spread over multiple lines for node `explanation`
        (childNode(withName: "explanation") as? SKLabelNode)?.fontName = "cartoon"
        (childNode(withName: "explanation") as? SKLabelNode)?.lineBreakMode = NSLineBreakMode.byWordWrapping
        (childNode(withName: "explanation") as? SKLabelNode)?.numberOfLines = 0
        (childNode(withName: "explanation") as? SKLabelNode)?.preferredMaxLayoutWidth = 400
        
        //Get all nodes with nanme SKLabelNode
        self.enumerateChildNodes(withName: "SKLabelNode") {
            (nodeX, stop) in
            //Get each node, and set a variable housing the same node, but as an SKLabelNode
            let node = nodeX as? SKLabelNode
            //Set the font of the node
            node?.fontName = "cartoon"
        }
    }

    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        //Get the first touch recognised and record its location within a variable
        let touch = touches.first!
        let touchLocation = touch.location(in: self)
        let touchedNode = atPoint(touchLocation)
        
        //Check if the touched node is the back symbol/button
        if touchedNode.name == "backSymbol" || touchedNode.name == "backButton" {
            //If so, switch back to `GameSceneStart` using the flipVertical transition
            let newScene = GameSceneStart(fileNamed: "GameSceneStart")
            let transition = SKTransition.flipVertical(withDuration: 1.0)
            newScene?.scaleMode = .aspectFill
            scene?.view?.presentScene(newScene!, transition: transition)
        }
    }
}

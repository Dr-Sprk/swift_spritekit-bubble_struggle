//
//  GameSceneLevel3.swift
//  Bubble Struggle
//
//  Created by Arjun Sharma on 2/11/19.
//  Copyright © 2019 Arjun Sharma. All rights reserved.
//

//Again, like level 2, this file uses much of the same code as level 1 so there is not much point in recommenting the entire thing, instead I will only comment where the code has changed from level 2

import SpriteKit
import GameplayKit

class GameSceneLevel3: SKScene, SKPhysicsContactDelegate {
    let BubbleCategory: UInt32 = 0x1 << 0
    let PlayerCategory: UInt32 = 0x1 << 1
    let PopperCategory: UInt32 = 0x1 << 2
    
    var player: SKSpriteNode?
    var bubble: SKSpriteNode?
    var bubble2: SKSpriteNode?
    //We now have a 3rd bubble initialised
    var bubble3: SKSpriteNode?
    
    var leftButton: SKSpriteNode?
    var rightButton: SKSpriteNode?
    
    var moveLeft: Bool = false
    var moveRight: Bool = false
    
    var popperMovement: Bool = false
    
    var popper = SKSpriteNode(imageNamed: "popper.png") as SKSpriteNode
    
    var ground: SKSpriteNode?
    
    var timerBar: SKSpriteNode?
    
    var isDead: Bool = false
    
    var scoreLabel: SKLabelNode?
    var levelLabel: SKLabelNode?
    var userLabel: SKLabelNode?
    
    var lives = 5
    var score = 0
    var username: String = ""
    var timer:Double = 180
    var beforePausedTime: Double = 0
    var levelComplete: Bool = false
    var isReset = false
    var countdown: Timer?
    
    override func didMove(to view: SKView) {
        if lives != 5 {
            for x in 0...(4-lives) {
                childNode(withName: "life\(5-x)")?.removeFromParent()
            }
        }
        
        player = childNode(withName: "player") as? SKSpriteNode
        player!.physicsBody!.categoryBitMask = PlayerCategory
        player!.physicsBody!.contactTestBitMask = BubbleCategory
        player!.physicsBody!.collisionBitMask = BubbleCategory
        
        bubble = childNode(withName: "Bubble") as? SKSpriteNode
        bubble!.texture = SKTexture(imageNamed: "yellowBall")
        bubble!.physicsBody!.categoryBitMask = BubbleCategory
        bubble!.physicsBody!.contactTestBitMask = PopperCategory | PlayerCategory
        bubble!.physicsBody!.collisionBitMask = PlayerCategory
        bubble!.physicsBody!.applyImpulse(CGVector(dx: -80, dy: 40))
        
        bubble2 = childNode(withName: "Bubble2") as? SKSpriteNode
        bubble2!.texture = SKTexture(imageNamed: "redBall")
        bubble2!.physicsBody!.categoryBitMask = BubbleCategory
        bubble2!.physicsBody!.contactTestBitMask = PopperCategory | PlayerCategory
        bubble2!.physicsBody!.collisionBitMask = PlayerCategory
        //This here is a random direction chooser for the middle ball as I couldn't decide which way the middle ball should go, so I made it random
        let directionChoose = Bool.random()
        if directionChoose == true {
            bubble2!.physicsBody!.applyImpulse(CGVector(dx: 160, dy: 40))
        } else if directionChoose == false {
            bubble2!.physicsBody!.applyImpulse(CGVector(dx: -160, dy: 40))
        }
        
        //Bubble3 is instantiated with the same physics as bubble, just with a different texture, and with the impulse going the opposite direction
        bubble3 = childNode(withName: "Bubble3") as? SKSpriteNode
        bubble3!.texture = SKTexture(imageNamed: "greenBall")
        bubble3!.physicsBody!.categoryBitMask = BubbleCategory
        bubble3!.physicsBody!.contactTestBitMask = PopperCategory | PlayerCategory
        bubble3!.physicsBody!.collisionBitMask = PlayerCategory
        bubble3!.physicsBody!.applyImpulse(CGVector(dx: 80, dy: 40))
        
        popper.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: (popper.texture?.size().width)!, height: (popper.texture?.size().height)!))
        popper.physicsBody!.friction = 1
        popper.physicsBody!.restitution = 0
        popper.physicsBody!.linearDamping = 1
        popper.physicsBody!.angularDamping = 1
        popper.physicsBody!.allowsRotation = false
        popper.physicsBody!.affectedByGravity = false
        popper.physicsBody!.categoryBitMask = PopperCategory
        popper.physicsBody!.contactTestBitMask = BubbleCategory
        popper.physicsBody!.collisionBitMask = 0
        
        scoreLabel = childNode(withName: "score") as? SKLabelNode
        scoreLabel?.fontName = "cartoon"
        scoreLabel?.text = String(score)
        
        userLabel = childNode(withName: "username") as? SKLabelNode
        userLabel?.fontName = "cartoon"
        userLabel?.text = username
        
        levelLabel = childNode(withName: "level") as? SKLabelNode
        levelLabel?.fontName = "cartoon"
        
        leftButton = childNode(withName: "leftButton") as? SKSpriteNode
        rightButton = childNode(withName: "rightButton") as? SKSpriteNode
        
        physicsWorld.contactDelegate = self
        physicsBody = SKPhysicsBody(edgeLoopFrom: frame)
        
        timerBar = childNode(withName: "timerBar") as? SKSpriteNode
        
        
        countdown = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { x in
            self.timer -= 0.1
        }
    }
    
    func didBegin(_ contact: SKPhysicsContact) {
        if ((contact.bodyA.categoryBitMask == PlayerCategory) && (contact.bodyB.categoryBitMask == BubbleCategory) || (contact.bodyA.categoryBitMask == BubbleCategory) && (contact.bodyB.categoryBitMask == PlayerCategory)) {
            print("player hit!")
            self.physicsWorld.speed = 0
            isDead = true
            player?.texture = SKTexture(imageNamed: "deathImage")
            let fadeOut = SKAction.fadeOut(withDuration: 0.5)
            player?.run(fadeOut)
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                self.isPaused = true
                if self.lives > 1 {
                    self.resetGame()
                } else {
                    self.gameOver()
                }
            }
        } else if ((contact.bodyA.categoryBitMask == PopperCategory) && (contact.bodyB.categoryBitMask == BubbleCategory)) || ((contact.bodyA.categoryBitMask == BubbleCategory) && (contact.bodyB.categoryBitMask == PopperCategory)) {
            if contact.bodyA.categoryBitMask == BubbleCategory {
                let hitBubble = contact.bodyA.node as? SKSpriteNode
                score += Int(Double(hitBubble!.size.width) * (timer/180))
                if Int((hitBubble?.size.width)!) > 20 {
                    let bubble1 = SKSpriteNode(texture: hitBubble!.texture, size: CGSize(width: (hitBubble?.size.width)!/2, height: (hitBubble?.size.height)!/2))
                    bubble1.physicsBody = SKPhysicsBody(circleOfRadius: (bubble1.size.width)/2)
                    bubble1.position = CGPoint(x: ((hitBubble?.position.x)! + (hitBubble?.size.width)!/2), y: (hitBubble?.position.y)!)
                    bubble1.physicsBody!.friction = 0
                    bubble1.physicsBody!.restitution = 1
                    bubble1.physicsBody!.linearDamping = 0
                    bubble1.physicsBody!.angularDamping = 0
                    bubble1.physicsBody!.allowsRotation = false
                    bubble1.physicsBody!.affectedByGravity = true
                    bubble1.physicsBody!.categoryBitMask = BubbleCategory
                    bubble1.physicsBody!.contactTestBitMask = PopperCategory | PlayerCategory
                    bubble1.physicsBody!.collisionBitMask = PlayerCategory
                    
                    let bubble2 = SKSpriteNode(texture: hitBubble!.texture, size: CGSize(width: (hitBubble?.size.width)!/2, height: (hitBubble?.size.height)!/2))
                    bubble2.physicsBody = SKPhysicsBody(circleOfRadius: (bubble2.size.width)/2)
                    bubble2.position = CGPoint(x: ((hitBubble?.position.x)! - (hitBubble?.size.width)!/2), y: (hitBubble?.position.y)!)
                    bubble2.physicsBody!.friction = 0
                    bubble2.physicsBody!.restitution = 1
                    bubble2.physicsBody!.linearDamping = 0
                    bubble2.physicsBody!.angularDamping = 0
                    bubble2.physicsBody!.allowsRotation = false
                    bubble2.physicsBody!.affectedByGravity = true
                    bubble2.physicsBody!.categoryBitMask = BubbleCategory
                    bubble2.physicsBody!.contactTestBitMask = PopperCategory | PlayerCategory
                    bubble2.physicsBody!.collisionBitMask = PlayerCategory
                    
                    self.addChild(bubble1)
                    self.addChild(bubble2)
                    hitBubble?.removeFromParent()
                    bubble1.physicsBody?.applyImpulse(CGVector(dx: bubble1.size.width/4, dy: bubble1.size.height/4))
                    bubble2.physicsBody?.applyImpulse(CGVector(dx: -bubble2.size.width/4, dy: bubble2.size.height/4))
                    popper.removeFromParent()
                    popperMovement = false
                } else {
                    hitBubble?.removeFromParent()
                    popper.removeFromParent()
                    popperMovement = false
                }
            } else if contact.bodyB.categoryBitMask == BubbleCategory {
                let hitBubble = contact.bodyB.node as? SKSpriteNode
                score += Int(Double(hitBubble!.size.width) * (timer/180))
                if Int((hitBubble?.size.width)!) > 20 {
                    let bubble1 = SKSpriteNode(texture: hitBubble!.texture, size: CGSize(width: (hitBubble?.size.width)!/2, height: (hitBubble?.size.height)!/2))
                    bubble1.physicsBody = SKPhysicsBody(circleOfRadius: (bubble1.size.width)/2)
                    bubble1.position = CGPoint(x: ((hitBubble?.position.x)! + (hitBubble?.size.width)!/2), y: (hitBubble?.position.y)!)
                    bubble1.physicsBody!.friction = 0
                    bubble1.physicsBody!.restitution = 1
                    bubble1.physicsBody!.linearDamping = 0
                    bubble1.physicsBody!.angularDamping = 0
                    bubble1.physicsBody!.allowsRotation = false
                    bubble1.physicsBody!.affectedByGravity = true
                    bubble1.physicsBody!.categoryBitMask = BubbleCategory
                    bubble1.physicsBody!.contactTestBitMask = PopperCategory | PlayerCategory
                    bubble1.physicsBody!.collisionBitMask = PlayerCategory
                    
                    let bubble2 = SKSpriteNode(texture: hitBubble!.texture, size: CGSize(width: (hitBubble?.size.width)!/2, height: (hitBubble?.size.height)!/2))
                    bubble2.physicsBody = SKPhysicsBody(circleOfRadius: (bubble2.size.width)/2)
                    bubble2.position = CGPoint(x: ((hitBubble?.position.x)! - (hitBubble?.size.width)!/2), y: (hitBubble?.position.y)!)
                    bubble2.physicsBody!.friction = 0
                    bubble2.physicsBody!.restitution = 1
                    bubble2.physicsBody!.linearDamping = 0
                    bubble2.physicsBody!.angularDamping = 0
                    bubble2.physicsBody!.allowsRotation = false
                    bubble2.physicsBody!.affectedByGravity = true
                    bubble2.physicsBody!.categoryBitMask = BubbleCategory
                    bubble2.physicsBody!.contactTestBitMask = PopperCategory | PlayerCategory
                    bubble2.physicsBody!.collisionBitMask = PlayerCategory
                    
                    self.addChild(bubble1)
                    self.addChild(bubble2)
                    hitBubble?.removeFromParent()
                    bubble1.physicsBody?.applyImpulse(CGVector(dx: bubble1.size.width/4, dy: bubble1.size.height/4))
                    bubble2.physicsBody?.applyImpulse(CGVector(dx: -bubble2.size.width/4, dy: bubble2.size.height/4))
                    popper.removeFromParent()
                    popperMovement = false
                } else {
                    hitBubble?.removeFromParent()
                    popper.removeFromParent()
                    popperMovement = false
                }
            }
        }
    }
    
    func touchDown(atPoint pos : CGPoint) {
        
    }
    
    func touchMoved(toPoint pos : CGPoint) {
        
    }
    
    func touchUp(atPoint pos : CGPoint) {
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first!
        let touchLocation = touch.location(in: self)
        let touchedNode = atPoint(touchLocation)
        
        if touchedNode.name == "leftButton" {
            moveLeft = true
        }
        
        if touchedNode.name == "rightButton" {
            moveRight = true
        }
        
        if touchedNode.name == "pause" {
            paused()
        }
        
        if touchedNode.name == "resumeButton" || touchedNode.name == "resumeLabel" {
            self.isPaused = false
            self.physicsWorld.speed = 1
            timer = beforePausedTime
            for node in self.children as [SKNode] {
                node.isPaused = false
            }
            childNode(withName: "pauseScreen")?.removeFromParent()
            childNode(withName: "pauseLabel")?.removeFromParent()
            childNode(withName: "resumeButton")?.removeFromParent()
            childNode(withName: "exitButton")?.removeFromParent()
            childNode(withName: "resumeLabel")?.removeFromParent()
            childNode(withName: "exitLabel")?.removeFromParent()
        }
        
        if touchedNode.name == "exitButton" || touchedNode.name == "exitLabel" {
            let newScene = GameSceneStart(fileNamed: "GameSceneStart")
            let transition = SKTransition.flipVertical(withDuration: 1.0)
            newScene?.scaleMode = .aspectFill
            scene?.view?.presentScene(newScene!, transition: transition)
        }
        
        if popperMovement == false {
            if touchedNode.name == "shoot" {
                popper.size.height = 630
                popper.size.width = 8
                popper.zPosition = -1
                popper.position = CGPoint(x: player!.position.x, y: -475.5)
                self.addChild(popper)
                popperMovement = true
            }
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch = touches.first!
        let touchLocation = touch.location(in: self)
        let touchedNode = atPoint(touchLocation)
        
        if touchedNode.name == "leftButton" {
            moveRight = false
            moveLeft = true
        }
        
        if touchedNode.name == "rightButton" {
            moveLeft = false
            moveRight = true
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if moveLeft == true {
            moveLeft = false
            player?.texture = SKTexture(imageNamed: "Player")
        }
        if moveRight == true {
            moveRight = false
            player?.texture = SKTexture(imageNamed: "Player")
        }
    }
    
    override func update(_ currentTime: TimeInterval) {
        var noOfBubbles: Int = 0
        
        timerBar!.size.width = 1600 * CGFloat(timer/180)
        if moveLeft == true {
            player?.position.x -= 3
            player?.texture = SKTexture(imageNamed: "Left Motion")
        }
        if moveRight == true {
            player?.position.x += 3
            player?.texture = SKTexture(imageNamed: "Right Motion")
        }
        if popperMovement == true {
            popper.position.y += 7.5
        }
        if popper.position.y >= 76 {
            popper.removeFromParent()
            popperMovement = false
        }
        if isDead == true {
            player?.position.y += 1
        }
        scoreLabel?.text = String(score)
        for node in self.children {
            if node.physicsBody?.categoryBitMask == BubbleCategory {
                noOfBubbles += 1
            }
        }
        if noOfBubbles == 0 {
            if !levelComplete {
                levelCompleteFunc()
                levelComplete = true
            }
        }
        
        if timer <= 0 && isReset == false {
            countdown!.invalidate()
            for node in self.children {
                if node.physicsBody?.categoryBitMask == BubbleCategory {
                    node.physicsBody?.isResting = true
                }
            }
            let timeUpLabel = SKLabelNode(fontNamed: "cartoon")
            timeUpLabel.text = "Time up!"
            timeUpLabel.fontSize = 80
            timeUpLabel.fontColor = SKColor.systemYellow
            timeUpLabel.position = CGPoint(x: 0, y: 0)
            timeUpLabel.zPosition = 4
            timeUpLabel.alpha = 1
            self.addChild(timeUpLabel)
            Timer.scheduledTimer(withTimeInterval: 3, repeats: false) {_ in
                timeUpLabel.removeFromParent()
                self.resetGame()
            }
            isReset = true
        }
    }
    
    func resetGame() {
        isDead = false
        let alphaBackground = SKShapeNode(rectOf: CGSize(width: frame.width, height: frame.height))
        alphaBackground.zPosition = 3
        alphaBackground.position = CGPoint(x: 0, y: 0)
        alphaBackground.fillColor = SKColor.black
        alphaBackground.alpha = 0.01
        self.addChild(alphaBackground)
        popper.removeFromParent()
        popperMovement = false
        player?.position = CGPoint(x: 0, y: -199.65)
        player?.texture = SKTexture(imageNamed: "Player")
        player?.alpha = 1
        bubble?.position = CGPoint(x: -350, y: 30)
        bubble2?.position = CGPoint(x: 0, y: 30)
        //Reset bubble3's position
        bubble3?.position = CGPoint(x: 350, y: 30)
        childNode(withName: "life" + String(lives))?.removeFromParent()
        lives -= 1
        alphaBackground.removeFromParent()
        isPaused = false
        self.physicsWorld.speed = 1
        for node in self.children {
            if node.physicsBody?.categoryBitMask == BubbleCategory {
                node.removeFromParent()
            }
        }
        timer = 180
        self.addChild(bubble!)
        self.addChild(bubble2!)
        //Readd bubble3 to the scene
        self.addChild(bubble3!)
        bubble!.physicsBody?.applyImpulse(CGVector(dx: -80, dy: 40))
        let directionChoose = Bool.random()
        if directionChoose == true {
            bubble2!.physicsBody!.applyImpulse(CGVector(dx: 160, dy: 40))
        } else if directionChoose == false {
            bubble2!.physicsBody!.applyImpulse(CGVector(dx: -160, dy: 40))
        }
        //Apply the starter impulse to bubble3
        bubble3!.physicsBody?.applyImpulse(CGVector(dx: 80, dy: 40))
        player?.physicsBody!.isResting = true
    }
    
    func gameOver() {
        self.physicsWorld.speed = 0
        self.isPaused = false
        
        let alphaBackground = SKShapeNode(rectOf: CGSize(width: frame.width, height: frame.height))
        alphaBackground.zPosition = 3
        alphaBackground.position = CGPoint(x: 0, y: 0)
        alphaBackground.fillColor = SKColor.black
        alphaBackground.alpha = 0
        
        let gameOverLabel = SKLabelNode(fontNamed: "cartoon")
        gameOverLabel.text = "Game Over"
        gameOverLabel.fontSize = 80
        gameOverLabel.fontColor = SKColor.systemYellow
        gameOverLabel.position = CGPoint(x: 0, y: 0)
        gameOverLabel.zPosition = 4
        gameOverLabel.alpha = 0
        
        let transitionLabel = SKLabelNode(fontNamed: "cartoon")
        transitionLabel.text = "And now for your score..."
        transitionLabel.fontSize = 50
        transitionLabel.position = CGPoint(x: 390, y: -200)
        transitionLabel.zPosition = 4
        transitionLabel.alpha = 0
        
        let fadeIn = SKAction.fadeIn(withDuration: 1)
        let mildFadeIn = SKAction.fadeAlpha(to: 0.7, duration: 1)
        
        self.addChild(alphaBackground)
        self.addChild(gameOverLabel)
        alphaBackground.run(mildFadeIn)
        gameOverLabel.run(fadeIn)
        Timer.scheduledTimer(withTimeInterval: 3, repeats: false) { x in
            self.addChild(transitionLabel)
            transitionLabel.run(fadeIn)
            x.invalidate()
            Timer.scheduledTimer(withTimeInterval: 2, repeats: false) { x in
                let newScene = GameSceneEndScore(fileNamed: "GameSceneEndScore")
                let transition = SKTransition.flipHorizontal(withDuration: 1)
                newScene?.username = self.username
                newScene?.score = self.score
                newScene?.scaleMode = .aspectFill
                self.scene?.view?.presentScene(newScene!, transition: transition)
                x.invalidate()
            }
        }
    }
    
    func paused() {
        beforePausedTime = timer
        self.isPaused = true
        self.physicsWorld.speed = 0
        for node in self.children as [SKNode] {
            node.isPaused = true
        }
        
        let pauseAlphaBackground = SKShapeNode(rectOf: CGSize(width: frame.width, height: frame.height))
        pauseAlphaBackground.zPosition = 3
        pauseAlphaBackground.name = "pauseScreen"
        pauseAlphaBackground.position = CGPoint(x: 0, y: 0)
        pauseAlphaBackground.fillColor = SKColor.black
        pauseAlphaBackground.alpha = 0.7
        
        let pausedHeader = SKLabelNode(fontNamed: "cartoon")
        pausedHeader.text = "Paused"
        pausedHeader.name = "pauseLabel"
        pausedHeader.zPosition = 4
        pausedHeader.fontColor = SKColor.systemYellow
        pausedHeader.fontSize = 55
        pausedHeader.position = CGPoint(x: 0, y: 60)
        
        let resumeSquare = SKShapeNode(rectOf: CGSize(width: 400, height: 70))
        resumeSquare.zPosition = 4
        resumeSquare.name = "resumeButton"
        resumeSquare.fillColor = SKColor.systemRed
        resumeSquare.strokeColor = SKColor.systemYellow
        resumeSquare.lineWidth = 3
        resumeSquare.position = CGPoint(x: 0, y: 0)
        
        let resumeLabel = SKLabelNode(fontNamed: "cartoon")
        resumeLabel.zPosition = 5
        resumeLabel.text = "Back to game"
        resumeLabel.name = "resumeLabel"
        resumeLabel.fontColor = SKColor.systemYellow
        resumeLabel.position = CGPoint(x: 0, y: -10)
        
        let exitSquare = SKShapeNode(rectOf: CGSize(width: 400, height: 70))
        exitSquare.zPosition = 4
        exitSquare.name = "exitButton"
        exitSquare.fillColor = SKColor.systemRed
        exitSquare.strokeColor = SKColor.systemYellow
        exitSquare.lineWidth = 3
        exitSquare.position = CGPoint(x: 0, y: -80)
        
        let exitLabel = SKLabelNode(fontNamed: "cartoon")
        exitLabel.zPosition = 5
        exitLabel.text = "Quit to main screen"
        exitLabel.name = "exitLabel"
        exitLabel.fontColor = SKColor.systemYellow
        exitLabel.position = CGPoint(x: 0, y: -90)
        
        self.addChild(pauseAlphaBackground)
        self.addChild(pausedHeader)
        self.addChild(resumeSquare)
        self.addChild(exitSquare)
        self.addChild(resumeLabel)
        self.addChild(exitLabel)
    }
    
    func levelCompleteFunc() {
        self.physicsWorld.speed = 0
        self.isPaused = false
        
        let congratsLabel = SKLabelNode(fontNamed: "cartoon")
        let textRandomiser = Int.random(in: 1...3)
        if textRandomiser == 1 {
            congratsLabel.text = "Congratulations!"
        } else if textRandomiser == 2 {
            congratsLabel.text = "Bravo!"
        } else {
            congratsLabel.text = "Awesome!"
        }
        congratsLabel.fontSize = 80
        congratsLabel.fontColor = SKColor.systemYellow
        congratsLabel.position = CGPoint(x: 0, y: 0)
        congratsLabel.zPosition = 4
        congratsLabel.alpha = 1
        
        score += Int(timer)
        score += 250
        
        let endGameAlphaBackground = SKShapeNode(rectOf: CGSize(width: frame.width, height: frame.height))
        endGameAlphaBackground.zPosition = 3
        endGameAlphaBackground.position = CGPoint(x: 0, y: 0)
        endGameAlphaBackground.fillColor = SKColor.black
        endGameAlphaBackground.alpha = 0.01
        
        self.addChild(congratsLabel)
        self.addChild(endGameAlphaBackground)
        Timer.scheduledTimer(withTimeInterval: 3, repeats: false) { x in
            //This time, since there are no more levels, send the information to GameSceneEndScore, to wrap up the player's round
            let newScene = GameSceneEndScore(fileNamed: "GameSceneEndScore")
            let transition = SKTransition.flipHorizontal(withDuration: 1)
            newScene?.username = self.username
            newScene?.score = self.score
            newScene?.scaleMode = .aspectFill
            self.scene?.view?.presentScene(newScene!, transition: transition)
            x.invalidate()
        }
    }
}
